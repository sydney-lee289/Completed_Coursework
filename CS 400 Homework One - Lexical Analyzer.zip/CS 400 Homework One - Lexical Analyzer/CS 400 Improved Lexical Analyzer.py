#Lexical Analyzer


token_values = dict()
token_values["+"] = 'ADD_OPERATOR'
token_values["-"] = 'SUBTRACT_OPERATOR'
token_values["*"] = 'MULTIPLICATION_OPERATOR'
token_values["/"] = 'DIVISION_OPERATOR'
token_values["("] = 'LEFT_PARENTHESIS'
token_values[")"] = 'RIGHT_PARENTHESIS'
token_values["="] = 'EQUAL_OPERATOR'
#just added eof
token_values["END_OF_INPUT"] = ['EOF']


myInput = str(input("Enter a String: "))
charclass = None
current_index = 0
nextToken = None
nextLexeme = None
lexCount = []
def getNonBlankCharacter():
    global current_index
    temp = myInput[current_index]
    while (temp.isspace()):
        current_index += 1
        temp = myInput[current_index]

    return temp



def lex():
    global current_index, nextLexeme, nextToken
    if current_index < len(myInput):
        current_char = getNonBlankCharacter()
        
       
        if current_char in token_values.keys():
            current_index += 1
            nextLexeme = current_char
            nextToken = token_values[current_char]
            lexCount.append(nextLexeme)
            return (current_char, token_values[current_char])
        elif current_char.isdigit() == True:
            lexeme = ''
            token = 'INT_LITERAL'

            while(current_char.isdigit()):
                    lexeme += current_char
                    current_index += 1
                    if current_index < len(myInput):
                        current_char = myInput[current_index]
                    else:
                        break           
            nextLexeme = lexeme
            nextToken = token
            lexCount.append(nextLexeme)
            return (lexeme, token)
        elif current_char.isalpha():
            lexeme = ''
            token = 'IDENTIFIER'
            while(current_char.isalnum() ):
                    lexeme += current_char
                    current_index += 1
                    if current_index < len(myInput):
                        current_char = myInput[current_index]
                    else:
                        break
            nextLexeme = lexeme
            nextToken = token 
            lexCount.append(nextLexeme)        
            return (lexeme, token)
        
    if current_index == len(myInput):   
        #print("EOF", "END OF INPUT")
        print(f"Lexeme#{len(lexCount) + 1} is END_OF_INPUT, which is a 'EOF' token.")
        
def expr():
     term()
     while(nextToken == token_values["+"] or nextToken == token_values["-"]) or nextToken == token_values["="]:
        #print(nextLexeme, nextToken)
        print(f"Lexeme#{len(lexCount)} is {nextLexeme}, which is a '{nextToken}' token.")
        lex()
        term()

def term():
    factor()
    while(nextToken == token_values["*"] or nextToken == token_values["/"]):
        #print(nextLexeme, nextToken)
        print(f"Lexeme#{len(lexCount)} is {nextLexeme}, which is a '{nextToken}' token.")
        lex()
        factor()


def factor():
    if nextToken == "IDENTIFIER" or nextToken == "INT_LITERAL":
        #print(nextLexeme, nextToken)
        print(f"Lexeme#{len(lexCount)} is {nextLexeme}, which is a '{nextToken}' token.")
        lex()
        return True
    
    elif nextToken == "LEFT_PARENTHESIS":
        #print(nextLexeme, nextToken)
        print(f"Lexeme#{len(lexCount)} is {nextLexeme}, which is a '{nextToken}' token.")
        lex()
        expr()
        if nextToken == "RIGHT_PARENTHESIS":
            #print(nextLexeme, nextToken)
            print(f"Lexeme#{len(lexCount)} is {nextLexeme}, which is a '{nextToken}' token.")
            lex()
            return True
        else:
            lex()
            print(nextToken)
            print("   Error!!!")
    else:
        lex()
        print('444Error!')

        
#lex()
#expr()

def format():
    lex()
    expr()


format()

