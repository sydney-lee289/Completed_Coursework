# linear regression

import csv
import numpy as np
import matplotlib.pyplot as plt

def load_files(filename):
    x = []
    y = []
    with open(filename, 'r') as file:
        csvreader = csv.reader(file)
        next(csvreader)  
        for row in csvreader:
            if len(row) < 2:
                print(f"Skipping invalid row (too few columns): {row}")
                continue
            try:
                x_val = float(row[0])
                y_val = float(row[1])
                x.append(x_val)
                y.append(y_val)
            except ValueError as e:
                print(f"Skipping row with invalid data: {row} | Error: {e}")
                continue
    return np.array(x), np.array(y)

def normalize_data(x, y):
    # Normalize x and y for zero mean and unit variance
    x = (x - np.mean(x)) / np.std(x)
    y = (y - np.mean(y)) / np.std(y)
    return x, y

def cost_function(x, y, m, c):
    N = len(x)
    predictionsline = m * x + c
    cost = (1/(2*N)) * np.sum((predictionsline-y) ** 2)
    return cost

def gradient_descent(x, y, m, c, alpha, epochs):
    N = len(x)
    total_error = []

    for i in range(epochs):
        predictionsline = m * x + c
        error = predictionsline - y 

        dm = (1 / N) * np.sum(error * x)
        dc = (1 / N) * np.sum(error)

        m -= alpha * dm
        c -= alpha * dc

        cost = cost_function(x, y, m, c)
        total_error.append(cost)

    return m, c, total_error

def plot_training(x_train, y_train, m, c):
    plt.scatter(x_train, y_train, color='blue', label='Training data')
    plt.plot(x_train, m * x_train + c, color='red', label=f'Fitted line (y = {m:.2f}x + {c:.2f})')
    plt.title('Training Data and Fitted Line')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.show()

# Function to plot test data and predictions
def plot_test(x_test, y_test, m, c):
    plt.scatter(x_test, y_test, color='green', label='Test data')
    plt.plot(x_test, m * x_test + c, color='orange', label='Regression line')
    plt.title('Test Data and Predicted Line')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.show()

# Function to plot cost function history
def plot_cost_history(cost_history):
    plt.plot(range(len(cost_history)), cost_history, color='purple')
    plt.title('Cost Function Convergence')
    plt.xlabel('Iterations')
    plt.ylabel('Cost')
    plt.show()

def main():

    train_x, train_y = load_files('train.csv')
    test_x, test_y = load_files('test.csv')

    m = np.random.randn() * 0.01
    c = np.random.randn() * 0.01

    alpha = 0.01
    epochs = 1000

    train_x, train_y = normalize_data(train_x, train_y)
    test_x, test_y = normalize_data(test_x, test_y)

    m, c, total_error = gradient_descent(train_x, train_y, m, c, alpha, epochs)

    plot_training(train_x, train_y, m, c)

    # Plot test data and the predicted line
    plot_test(test_x, test_y, m, c)

    # Plot cost function convergence
    plot_cost_history(total_error)

if __name__ == '__main__':
    main()