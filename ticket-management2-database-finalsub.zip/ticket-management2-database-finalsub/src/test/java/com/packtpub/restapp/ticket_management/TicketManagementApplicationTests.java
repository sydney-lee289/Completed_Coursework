package com.packtpub.restapp.ticket_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
