package com.packtpub.model.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="product")
public class Product{
	
	@Id
	private String prodnr;
	private String prodname;
	private String prodtype;
	private Integer available_quantity;
	
	public Product(){
		
	}
	
	public Product(String prodnr, String prodname, String prodtype, Integer available_quantity) {
		this.setProdnr(prodnr);		
		this.setProdname(prodname);
		this.setProdtype(prodtype);
		this.setAvailable_quantity(available_quantity);
	}
	public String getProdnr() {
		return prodnr;
	}

	public void setProdnr(String prodnr) {
		this.prodnr = prodnr;
	}

	public String getProdname() {
		return prodname;
	}

	public void setProdname(String prodname) {
		this.prodname = prodname;
	}

	public String getProdtype() {
		return prodtype;
	}

	public void setProdtype(String prodtype) {
		this.prodtype = prodtype;
	}

	public Integer getAvailable_quantity() {
		return available_quantity;
	}

	public void setAvailable_quantity(Integer available_quantity) {
		this.available_quantity = available_quantity;
	}
	
	
}