package com.packtpub.service;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.packtpub.model.entity.User;
import com.packtpub.model.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	public static List <User> users;
	public UserServiceImpl() {
		users = new LinkedList<>();
		users.add(new User(100, "David"));
		users.add(new User(101,"Peter")); 
		users.add(new User(102,"John"));
	}
	
	@Autowired
	UserRepository userRepository;
	
	
	@Override
	public List<User> getAllUsers(){
		return userRepository.findAll();
	}
	
	@Override
	public User getUser(Integer userid) {
		Optional<User> result = userRepository.findById(userid);
		if (result == null) {
			return null;
			}
		return result.get();
	
	}
	@Override
	public void createUser(Integer userid, String username) {
		User userToInsert = new User(userid, username);
		userRepository.save(userToInsert);
		}
		
	@Override public void updateUser(Integer userid, String username) {
		Optional<User> result = userRepository.findById(userid);
		if (result != null) {
			User user = result.get();
			if(user != null) {
				user.setUsername(username);
				userRepository.saveAndFlush(user);
			}
		}
	
	}
		  
	@Override public void deleteUser(Integer userid) {
		userRepository.deleteById(userid);
	}
		 
}
