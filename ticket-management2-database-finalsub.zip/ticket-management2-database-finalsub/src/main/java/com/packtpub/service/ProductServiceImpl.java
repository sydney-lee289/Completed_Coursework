package com.packtpub.service;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.packtpub.model.entity.Product;
import com.packtpub.model.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepository productRepository;

	@Override
	public List<Product> getAllProducts() {
		return productRepository.findAll();
		
	}

	@Override
	public Product getProduct(String prodnr){
		Optional<Product> result = productRepository.findById(prodnr);
		if (result == null) {
			return null;
		}
		return result.get();
	}

	@Override
	public void createProduct(String prodnr, String prodname, String prodtype, Integer available_quantity) {
		Product productToInsert = new Product(prodnr, prodname, prodtype, available_quantity);
		productRepository.save(productToInsert);
		
	}

	@Override
	public void updateProduct(String prodnr, String prodname, String prodtype, Integer available_quantity) {
		Optional<Product> result = productRepository.findById(prodnr);
		if (result != null) {
			Product product = result.get();
			if (product != null) {
				product.setAvailable_quantity(available_quantity);
				product.setProdname(prodname);
				product.setProdtype(prodtype);
				productRepository.saveAndFlush(product);
			}
		}
		
	}

	@Override
	public void deleteProduct(String prodnr) {
		productRepository.deleteById(prodnr);
		
	}

		 
}
