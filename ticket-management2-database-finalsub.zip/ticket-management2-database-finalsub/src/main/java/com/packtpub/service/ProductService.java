package com.packtpub.service;
import java.util.List;

import com.packtpub.model.entity.Product;
public interface ProductService{
	List<Product> getAllProducts();
	
	  Product getProduct(String prodnr); void createProduct(String prodnr, String
	  prodname, String prodtype, Integer available_quantity); void updateProduct(String prodnr, String prodname, String prodtype, Integer available_quantity);
	  void deleteProduct(String prodnr);
	 
}

