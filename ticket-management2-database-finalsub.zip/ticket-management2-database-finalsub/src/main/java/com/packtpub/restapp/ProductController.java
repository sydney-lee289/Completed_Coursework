package com.packtpub.restapp;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.packtpub.model.entity.Product;
import com.packtpub.service.ProductService;



@RestController
@RequestMapping("/product")
public class ProductController{
	@Autowired
	ProductService productService;
	@ResponseBody
	@RequestMapping("")
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
		}
	@ResponseBody
	@RequestMapping("/{prodnr}")
	public Product getProduct(@PathVariable("prodnr") String prodnr) {
		return productService.getProduct(prodnr);
	}
	@ResponseBody
	@RequestMapping(value = "", method = RequestMethod.POST)
	public Map<String, Object> createProduct(
			@RequestParam(value="prodnr") String prodnr,
			@RequestParam(value="prodname") String prodname,
			@RequestParam(value="prodtype")String prodtype,
			@RequestParam(value="available_quantity")Integer available_quantity
			)
	{
		Map<String, Object> map = new LinkedHashMap<>();
		productService.createProduct(prodnr,prodname,prodtype,available_quantity);
		map.put("result","added");
		return map;
	}
	@ResponseBody	 
	@RequestMapping(value = "", method = RequestMethod.PUT)
	public Map<String,Object> updateProduct(
			@RequestParam(value="prodnr") String prodnr,
			@RequestParam(value="prodname") String prodname,
			@RequestParam(value="prodtype") String prodtype,
			@RequestParam(value="available_quantity")Integer available_quantity
			){ 
		    Map<String, Object> map = new LinkedHashMap<>();
		    productService.updateProduct(prodnr,prodname,prodtype,available_quantity);
		    map.put("result", "updated"); 
		    return map; 
		    }
	@ResponseBody
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public Map<String, Object> deleteUser(
			@PathVariable("id") String prodnr) {
		Map<String, Object> map = new LinkedHashMap<>();
		productService.deleteProduct(prodnr);
		map.put("result", "deleted");
		return map;
	}
	
		 
}