import java.util.Scanner;

public class LabProgram {
   
   // define your method here
   
   public static void main(String[] args) {
      // define Scanner object
      // read in inputWidth and inputHeight
      // define object labProgramObj of type LabProgram
      // print the result of calling method computeArea on object labProgramObj
      
   }
}